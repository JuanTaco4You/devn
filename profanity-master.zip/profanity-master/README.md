# profanity
This project was abandoned by me a couple of years ago. Fundamental security issues in the generation of private keys have been brought to my attention. See: https://github.com/johguse/profanity/issues/61

I strongly advice against using this tool in its current state. This repository will soon be further updated with additional information regarding this critical issue.

## 2022-09-15
All affected binaries have been removed to prevent further unsafe use of this tool, please see the following article for more information:

https://blog.1inch.io/a-vulnerability-disclosed-in-profanity-an-ethereum-vanity-address-tool-68ed7455fc8c

## 2022-09-15
As per issue 76 (https://github.com/johguse/profanity/issues/76) I've decided to also archive this repository to further reduce risk that someone uses this tool. The code will not recieve any updates and I've left it in an uncompilable state. Use something else!
